//
//  main.cpp
//  Pointers - Class Exercise
//
//  Created by Vector Mwendwa on 11/25/21.
//

#include <iostream>
using namespace std;

int main(){
    double number1;
    double number2;
    number1 = 7.3;
    double* ptr;
    ptr=&number1;
    cout<<"The value of the object pointed to by ptr is : "<<number1;
        cout<<"\n";
    number2=*ptr;
        cout<<"\n";
    cout<<"The address of the variable number 1 is : "<<&number1;
        cout<<"\n";
    cout<<"The address stored in ptr is : "<<ptr;
        cout<<"\n";
    return 0;
}
